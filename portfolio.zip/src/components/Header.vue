<template>
    <header class="mx-auto col-xl-12">
        <h1>RESUME</h1>
        <p><span>Web Publisher</span> &amp; <span>UI &amp; UX Design</span></p>
    </header>
</template>